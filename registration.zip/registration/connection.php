<?php
define('DB_SERVER', 'eu-cdbr-azure-north-d.cloudapp.net');
define('DB_USERNAME', 'b99256e599d9fc');
define('DB_PASSWORD', '64c23a04');
define('DB_DATABASE', 'rgutest');
$db = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);

?>
